/* Test that a process can exit using the exit library function */

#include <stdlib.h>

int main(void) {
	exit(0);
}
